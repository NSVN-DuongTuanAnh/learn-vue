export default {
  fetch({ redirect }) {
    redirect('/docs/directives/popover')
  }
}
