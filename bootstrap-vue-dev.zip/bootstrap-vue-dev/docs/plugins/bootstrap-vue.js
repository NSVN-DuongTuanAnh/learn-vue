import Vue from 'vue'
import BootstrapVue from '../../src'

Vue.use(BootstrapVue, {})
