// Legacy directive plugin names
// This should be removed if we plan on exporting all from
// the main /src/index.js file
export { default as BToggle } from './toggle'
export { default as BModal } from './modal'
export { default as BScrollspy } from './scrollspy'
export { default as BTooltip } from './tooltip'
export { default as BPopover } from './popover'
