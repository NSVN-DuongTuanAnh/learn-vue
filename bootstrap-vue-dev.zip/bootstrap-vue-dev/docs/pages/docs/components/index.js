export default {
  fetch({ redirect }) {
    redirect('/docs/components/alert')
  }
}
