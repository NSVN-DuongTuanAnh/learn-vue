import Vue from 'vue'
import CodeMirror from '../components/codemirror'

Vue.component('codemirror', CodeMirror)
