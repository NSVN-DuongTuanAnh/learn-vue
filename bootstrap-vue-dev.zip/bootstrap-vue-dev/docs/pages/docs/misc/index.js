export default {
  fetch({ redirect }) {
    redirect('/docs/misc/changelog')
  }
}
